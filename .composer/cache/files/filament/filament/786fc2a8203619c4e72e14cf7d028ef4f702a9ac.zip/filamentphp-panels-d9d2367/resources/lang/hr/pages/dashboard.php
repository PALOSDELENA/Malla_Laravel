<?php

return [

    'title' => 'Nadzorna ploča',

    'actions' => [

        'filter' => [

            'label' => 'Filter',

            'modal' => [

                'heading' => 'Filter',

                'actions' => [

                    'apply' => [

                        'label' => 'Primijeni',

                    ],

                ],

            ],

        ],

    ],

];
