<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'התנתק',
        ],

    ],

    'welcome' => 'ברוך הבא',

];
