<?php

return [

    'title' => ':label देखें',

    'breadcrumb' => 'देखें',

];
