<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'ცვლილებების შენახვა',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'შენახულია',
        ],

    ],

];
