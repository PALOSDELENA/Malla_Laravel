<?php

return [

    'breadcrumb' => 'Přehled',

];
