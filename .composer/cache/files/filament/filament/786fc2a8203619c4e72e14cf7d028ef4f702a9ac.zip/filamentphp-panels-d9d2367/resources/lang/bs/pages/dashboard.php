<?php

return [

    'title' => 'Nadzorna ploča',

];
