<?php

return [

    'breadcrumb' => '목록',

];
