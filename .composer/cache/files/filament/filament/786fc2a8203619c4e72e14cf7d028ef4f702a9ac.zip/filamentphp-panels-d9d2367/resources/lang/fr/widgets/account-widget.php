<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Déconnexion',
        ],

    ],

    'welcome' => 'Bonjour',

];
