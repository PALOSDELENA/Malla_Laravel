<?php

return [

    'distinct' => [
        'must_be_selected' => 'უნდა აირჩეს მინიმუმ ერთი :attribute ველი.',
        'only_one_must_be_selected' => 'უნდა აირჩეს მხოლოდ ერთი :attribute ველი.',
    ],

];
