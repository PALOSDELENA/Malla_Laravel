<?php

return [

    'distinct' => [
        'must_be_selected' => 'At least one :attribute field must be selected.',
        'only_one_must_be_selected' => 'Only one :attribute field must be selected.',
    ],

];
