<div
    class="fi-in-placeholder text-sm leading-6 text-gray-400 dark:text-gray-500"
>
    {{ $slot }}
</div>
