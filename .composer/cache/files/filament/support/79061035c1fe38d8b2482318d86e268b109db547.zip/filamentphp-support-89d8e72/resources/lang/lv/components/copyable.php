<?php

return [

    'messages' => [
        'copied' => 'Kopēts',
    ],

];
