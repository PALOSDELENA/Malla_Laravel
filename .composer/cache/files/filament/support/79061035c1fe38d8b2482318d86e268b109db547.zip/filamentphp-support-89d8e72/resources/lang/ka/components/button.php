<?php

return [

    'messages' => [
        'uploading_file' => 'ფაილის ატვირთვა...',
    ],

];
