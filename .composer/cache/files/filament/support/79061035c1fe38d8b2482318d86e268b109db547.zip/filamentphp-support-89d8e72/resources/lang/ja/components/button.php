<?php

return [

    'messages' => [
        'uploading_file' => 'ファイルをアップロード中...',
    ],

];
