<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Chiudi',
        ],

    ],

];
