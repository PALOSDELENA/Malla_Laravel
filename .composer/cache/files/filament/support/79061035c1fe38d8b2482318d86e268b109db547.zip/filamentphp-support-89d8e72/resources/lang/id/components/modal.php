<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Tutup',
        ],

    ],

];
