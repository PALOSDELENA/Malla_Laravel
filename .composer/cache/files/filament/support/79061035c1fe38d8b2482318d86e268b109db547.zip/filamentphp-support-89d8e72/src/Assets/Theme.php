<?php

namespace Filament\Support\Assets;

class Theme extends Css {}
