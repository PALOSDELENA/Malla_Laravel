<?php

namespace Filament\Tables\Actions;

/**
 * @deprecated Use `\Filament\Tables\Actions\Action` instead.
 * @see Action
 */
class LinkAction extends Action {}
