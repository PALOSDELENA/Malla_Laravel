<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Cache;

use Doctrine\DBAL\Exception;

class CacheException extends \Exception implements Exception
{
}
